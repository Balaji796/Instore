from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(stud)
admin.site.register(bill)
admin.site.register(customer)
 